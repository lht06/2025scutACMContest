#include "testlib.h"
#include <bits/stdc++.h>

int __main__(void);

int main(int argc, char *argv[]) {
    registerTestlibCmd(argc, argv);
    return __main__();
}
#define main __main__



bool format_check(const std::string &s, int size_0, int size_1) {
    if (static_cast<int>(s.size()) != size_0 + size_1) {
        return false;
    }

    for (char c : s) {
        if (c == '0') {
            size_0 -= 1;
        } else {
            size_1 -= 1;
        }
    }

    return size_0 == 0 and size_1 == 0;
}


int main() {
    /*
    * inf：输入
    * ouf：选手输出
    * ans：标准输出
    */

    int n = inf.readInt(0, 500); // 0
    int m = inf.readInt(0, 500); // 1

    std::string s = ouf.readString();

    if (s != "-1" and !format_check(s, n, m)) {
        quitf(_wa, "Wrong Answer with incorrect output format");     
    }

    int sum = n + m;
    if (std::min(n, m) < sum / 3) {
        if (s == "-1") {
            quitf(_ok, "Good job\n");     
        } else {
            quitf(_wa, "Wrong Answer expect -1 in n = %d, m = %d", n, m);     
        }
    }

    if (s == "-1") {
        quitf(_wa, "Wrong Answer expect ok but you sad -1");     
    }

    for (auto i = 1U; i + 1 < s.size(); i++) {
        if (s[i - 1] == s[i] and s[i] == s[i + 1]) {
            quitf(_wa, "Wrong Answer for three adjacent pieces of the same color");     
        }
    }

    quitf(_ok, "Good job\n");

    // quitf(_ok, "Good job\n");
    // quitf(_wa, "Wrong Answer because %d != %d + %d", x, y, z);

    return 0;
}