#include "testlib.h"
#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
const int N=500010;
std::mt19937_64 myrand(chrono::steady_clock::now().time_since_epoch().count());
int rd(int l,int r)
{
    return std::uniform_int_distribution<int>(l,r)(myrand);
}
struct HASH
{
    const int P1=1109,P2=3307,mod1=3036999473,mod2=3037000493;
    int h1[N],p1[N],h2[N],p2[N];
    void init(string &s)
    {
        p1[0]=p2[0]=1;
        int n=s.size()-1;
        for (int i=1;i<=n;i++)
        {
            h1[i]=(h1[i-1]*P1+s[i])%mod1,p1[i]=p1[i-1]*P1%mod1;
            h2[i]=(h2[i-1]*P2+s[i])%mod2,p2[i]=p2[i-1]*P2%mod2;
        }
    }
    int get1(int l,int r) {return (h1[r]-h1[l-1]*p1[r-l+1]%mod1+mod1)%mod1;}
    int get2(int l,int r) {return (h2[r]-h2[l-1]*p2[r-l+1]%mod2+mod2)%mod2;}
    array<int,2> get(int l,int r)
    {
        if (l>r) return {0,0};
        else return {get1(l,r),get2(l,r)};
    }
}S;
int ne[N];
int get_border(string s)
{
    for (int i=2,j=0;i<=n;i++)
    {
        while (j&&s[j+1]!=s[i]) j=ne[j];
        if (s[j+1]==s[i]) j++;
        ne[i]=j;
    }
    return ne[n];
}
bool check(string s)
{
    if (s.size()!=n) return false;
    for (auto c:s)
        if (c<'a'||c>'z') return false;
    s=" "+s;
    S.init(s);
    int len=get_border(s);
    if (len!=m) return false;
    int l=0,r=n-1;
    while (l<r)
    {
        int mid=l+r+1>>1;
        if (S.get(1,mid)==S.get(n-mid+1,n)) l=mid;
        else r=mid-1;
    }
    return len==l;
}

string get_std(int n,int m)
{
    if (m==0) return string(1,'a')+string(n-1,'b');
    else if (m==n-1) return string(n,'a');
    else if (2*m<n) return string(m,'a')+string(n-2*m,'b')+string(m,'a');
    else
    {
        int l=0,r=n-1,period=n-m;
        while (l<r)
        {
            int mid=l+r+1>>1;
            if (m>=mid)
            {
                period=__gcd(period,n-mid);
                l=mid;
            }
            else r=mid-1;
        }

        l=0,r=n-1;
        while (l<r)
        {
            int mid=l+r+1>>1;
            if (m>=mid) l=mid;
            else
            {
                int other_period=n-mid;
                if (other_period%period==0)
                {
                    return "-1";
                }
                r=mid-1;
            }
        }
        if (period!=n-m)
        {
            return "-1";
        }
        while (true)
        {
            string base;
            for (int i=1;i<=period;i++) base+=rd('a','z');
            string ans;
            while (ans.size()<n) ans+=base;
            while (ans.size()>n) ans.pop_back();
            bool flag=true;
            int l=0,r=n-1;
            while (l<r)
            {
                int mid=l+r+1>>1;
                if (m>=mid)
                {
                    l=mid;
                    if (ans.substr(0,mid)!=ans.substr(n-mid,mid))
                    {
                        flag=false;
                        break;
                    }
                }
                else
                {
                    r=mid-1;
                    if (ans.substr(0,mid)==ans.substr(n-mid,mid))
                    {
                        flag=false;
                        break;
                    }
                }
            }
            if (flag) return ans;
        }
    }
}

signed main(int argc, char* argv[])
{
    registerTestlibCmd(argc,argv);
    
    int t = inf.readInt();
    
    while (t--) {
        n = inf.readInt();
        m = inf.readInt();
        string s = ouf.readString();
        string std_ans=get_std(n,m);
        bool flag = true;
        
        if (s=="-1"&&std_ans!="-1") quitf(_wa, "There is a correct string. But you don't find it");
        else if (s!="-1") flag&=check(s);

        if (!flag) quitf(_wa, "find incorrect string");
    }
    quitf(_ok, "find all correct string");
    return 0;
}
