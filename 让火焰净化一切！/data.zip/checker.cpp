#include "testlib.h"
const double eps = 1e-6;
int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    while(!ans.eof()){
        double pans = ouf.readDouble();
        double jans = ans.readDouble();
        ans.readEoln();

        if (fabs(pans - jans) > eps)
            quitf(_wa, "The answer is wrong: expected = %f, found = %f", jans, pans);

    }
    quitf(_ok, "The answer is correct.");
    return 0;

}