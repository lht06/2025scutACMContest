#include "testlib.h"
#include <bits/stdc++.h>

int __main__(void);

int main(int argc, char *argv[]) {
    registerTestlibCmd(argc, argv);
    return __main__();
}
#define main __main__

template <class T, class G>
struct BaseVector2 {
    T x, y;
    constexpr BaseVector2() : BaseVector2(T{}, T{}) {}
    constexpr BaseVector2(T x, T y) : x{x}, y{y} {}

    // 运算
    constexpr BaseVector2 operator+(BaseVector2 a) const {
        return BaseVector2(x + a.x, y + a.y);
    }
    constexpr BaseVector2 operator-(BaseVector2 a) const {
        return BaseVector2(x - a.x, y - a.y);
    }
    constexpr BaseVector2 operator-() const {
        return BaseVector2(-x, -y);
    }
    constexpr G operator*(BaseVector2 a) const {
        return G(x) * a.x + G(y) * a.y;
    }
    constexpr G operator%(BaseVector2 a) const {
        return G(x) * a.y - G(y) * a.x;
    }
    constexpr BaseVector2 rotate() const {
        return BaseVector2(-y, x);
    }
    template <class F>
    constexpr BaseVector2 rotate(F theta) const {
        BaseVector2 b(std::cos(theta), std::sin(theta));
        return BaseVector2(x * b.x - y * b.y,
                           x * b.y + y * b.x);
    }
    constexpr friend BaseVector2 operator*(const T &a, BaseVector2 b) {
        return BaseVector2(a * b.x, a * b.y);
    }

    // 比较
    constexpr bool operator<(BaseVector2 a) const {
        if (x == a.x) {
            return y < a.y;
        }
        return x < a.x;
    }

    constexpr bool operator>(BaseVector2 a) const {
        if (x == a.x) {
            return y > a.y;
        }
        return x > a.x;
    }

    constexpr bool operator<=(BaseVector2 a) const {
        if (x == a.x) {
            return y <= a.y;
        }
        return x <= a.x;
    }

    constexpr bool operator>=(BaseVector2 a) const {
        if (x == a.x) {
            return y >= a.y;
        }
        return x >= a.x;
    }

    constexpr bool operator==(BaseVector2 a) const {
        return x == a.x and y == a.y;
    }

    constexpr bool operator!=(BaseVector2 a) const {
        return x != a.x or y != a.y;
    }

    // 输入输出
    friend std::istream &operator>>(std::istream &in, BaseVector2 &p) {
        return in >> p.x >> p.y;
    }
    friend std::ostream &operator<<(std::ostream &ot, BaseVector2 p) {
        return ot << '(' << p.x << ", " << p.y << ')';
    }
};

template <class T, class G>
G dis2(BaseVector2<T, G> a, BaseVector2<T, G> b = BaseVector2<T, G>(0, 0)) {
    BaseVector2<T, G> p = a - b;
    return p * p;
}

template <class T, class G>
int sgn(BaseVector2<T, G> p) {
    if (p.x < 0 or (p.x == 0 and p.y > 0)) {
        return 1;
    } else
        return 0;
    // 以41象限为先
}

template <class Vector>
bool polarCmp(Vector p, Vector q) {
    if (sgn(p) == sgn(q)) {
        if (p % q == 0) {
            return dis2(p) < dis2(q);
        } else {
            return p % q > 0;
        }
    } else {
        return sgn(p) < sgn(q);
    }
}

using Point = BaseVector2<int, long long>;
using Vector = Point;
using PS = std::vector<Point>;

PS convex(PS ps) {
    std::sort(ps.begin(), ps.end());
    ps.erase(std::unique(ps.begin(), ps.end()), ps.end());

    const int n = ps.size();
    if (n <= 1) {
        return ps;
    }

    PS hull(n + 1);
    int k = -1;

    for (int i = 0; i < n; i++) {
        while (k >= 1 and (hull[k] - hull[k - 1]) % (ps[i] - hull[k]) <= 0) {
            k -= 1;
        }
        hull[++k] = ps[i];
    }

    for (int i = n - 2, m = k + 1; i >= 0; i--) {
        while (k >= m and (hull[k] - hull[k - 1]) % (ps[i] - hull[k]) <= 0) {
            k -= 1;
        }
        hull[++k] = ps[i];
    }

    assert(k >= 2);
    return hull.resize(k), hull;
}

using u64 = unsigned long long;

template <class T, int Mod>
class HashTable {
    struct Iterator {
        u64 *pKey;
        T *pVal;

        Iterator(u64 *pKey, T *pVal) : pKey{pKey}, pVal{pVal} {}

        Iterator operator++() {
            ++pKey;
            ++pVal;

            return *this;
        }

        bool operator!=(Iterator it) const {
            return pKey != it.pKey;
        }

        std::pair<u64, T> operator*() {
            return std::make_pair(*pKey, *pVal);
        }
    };

    Iterator begin() {
        return Iterator(to + 1, val + 1);
    }

    Iterator end() {
        return Iterator(to + tot + 1, val + tot + 1);
    }

    int hd[Mod], nt[Mod << 1], tot = 0;
    u64 to[Mod << 1];
    T val[Mod << 1];
public:
    void clear() {
        for (int i = 1; i <= tot; i++)
            hd[to[i] % Mod] = 0;
        tot = 0;
    }

    T operator()(u64 x) {
        int u = x % Mod;
        for (int i = hd[u]; i; i = nt[i])
            if (to[i] == x)
                return val[i];
        return T();
    }

    T &operator[](u64 x) {
        int u = x % Mod;
        for (int i = hd[u]; i; i = nt[i])
            if (to[i] == x)
                return val[i];
        to[++tot] = x;
        nt[tot] = hd[u];
        hd[u] = tot;
        return val[tot] = T();
    }
};

HashTable<bool, int(1e3) + 3> mp;

template <class T>
T gcd(T a, T b) {
    if (b == 0) {
        return a;
    }

    return gcd(b, a % b);
}

Vector simply(Vector vt) {
    int x = vt.x;
    int y = vt.y;

    if (x == 0 and y == 0) {
        return vt;
    }

    if (sgn(vt) == 1) {
        x *= -1;
        y *= -1;
    }

    int g = gcd(std::abs(x), std::abs(y));
    x /= g;
    y /= g;
    
    return Vector{x, y};
}

int main() {
    /*
    * inf：输入
    * ouf：选手输出
    * ans：标准输出
    */

    int n = inf.readInt(3, 500); // 外
    int m = inf.readInt(0, 500); // 内

    PS ps(n + m);
    for (Point &p : ps) {
        static constexpr int Limit = 1E9;
        p.x = ouf.readInt(0, Limit);
        p.y = ouf.readInt(0, Limit);
    }

    std::sort(ps.begin(), ps.end());
    ps.erase(std::unique(ps.begin(), ps.end()), ps.end());

    if ((int)ps.size() < n + m) {
        quitf(_wa, "There are two points with the same coordinates");    
    }

    PS conps = convex(ps);
    if ((int)conps.size() != n) {
        if ((int)conps.size() > n) {
            quitf(_wa, "The number of points on the convex hull is > n");    
        }
        if ((int)conps.size() < n) {
            quitf(_wa, "The number of points on the convex hull is < n");    
        }
    }

    for (int i = 0; i < n + m; i++) {
        mp.clear();
        for (int j = 0; j < n + m; j++) {
            if (i == j) {
                continue;
            }

            auto p = simply(ps[i] - ps[j]);
            int x = p.x;
            int y = p.y;
            u64 h = (u64(x) << 32) ^ y;
            if (mp(h)) {
                quitf(_wa, "There are three collinear points");    
            }
            mp[h] = true;
        }
    }

    quitf(_ok, "Good job\n");

    // quitf(_ok, "Good job\n");
    // quitf(_wa, "Wrong Answer because %d != %d + %d", x, y, z);

    return 0;
}