#include "testlib.h"
#include <map>
#define ll long long
using namespace std;
map<ll,bool>M;
int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    ll out1 = ouf.readLong((ll)1,(ll)200);
    ll out2 = ouf.readLong((ll)1,(ll)200);
    ll n = ans.readLong();
    for(int i=1;i<=n;i++)
    {
        ll a,b;
        a=ans.readLong();
        b=ans.readLong();
        M[a*1000+b]=true;
    }

    if (M[out1*1000+out2]==true||M[out2*1000+out1]==true)
        quitf(_ok, "The answer is correct.");
    else
        quitf(_wa, "The answer is wrong.");
}
